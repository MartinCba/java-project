package com.company;

public class Funciones {
    public static void main(String[] args) {
        holaMundo();
        devolverHolaMundo("Martín");
        holaMundo();
        devolverHolaMundo("Luca");
        holaMundo();
        devolverHolaMundo("Julian");
        String hola = chauMundo();
        System.out.println(hola);
    }

    private static String chauMundo() {
        return "Chau mundo!!";
    }

    private static void devolverHolaMundo(String name) {
        System.out.println("Hola "+ name);
    }

    private static void holaMundo() {
        System.out.println("Hola mundo!!!!");
    }
}
