package com.company;

public class operadores {
    public static void main(String[] args) {
        // operadores

        // aritmeticos

        // + - / * %
        int num1 = 5;
        int num2 = 2;

        int resultado = num1 + num2;
        int resultado2 = num2 - num1;
        int resultado3 = num1 * num2;
        int resultado4 = num1 / num2;

        // logicos, relación, comparación, booleanos
        /*
         * <
         * >
         * <=
         * >=
         * ==
         * !=
         * && and
         * || or
         * !
         */

        // asignacion
        /*
         * =
         * +=
         * -=
         * /=
         * *=
         * %=
         */

        // incremento
        // ++

        // decremento
        // --

        // concatenacion
        // +
}}



