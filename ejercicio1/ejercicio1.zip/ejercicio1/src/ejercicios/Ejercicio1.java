package ejercicios;

public class Ejercicio1 {
    public static void main(String[] args) {
        byte number1 =1;
        short number2 = 2;
        int number3 = 3;
        long number4 = 4;
        float decimal1 = 4.9f;
        double decimal2 = 9.99d;
        char caracter1 = 'a';
        boolean verdadero = true;
        boolean falso = false;
        String nombre = "Martín Hernandez";
        Integer numero = null;
        Long numero2 = 2L;

        System.out.println("byte: " + number1);
        System.out.println("short: " + number2);
        System.out.println("int: " + number3);
        System.out.println("long: " + number4);
        System.out.println("float: " + decimal1);
        System.out.println("double: " + decimal2);
        System.out.println("char: " + caracter1);
        System.out.println("boolean: " + verdadero);
        System.out.println("boolean: " + falso);
        System.out.println("String: " + nombre);
        System.out.println("Integer: " + numero);
        System.out.println("Long: " + numero2);
    }
}
